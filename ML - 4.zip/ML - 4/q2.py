import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, mean_absolute_percentage_error, r2_score

# Load dataset
df = pd.read_csv("GiveMeSomeCredit.csv")

# Example regression: predict "age"
X_reg = df.drop(["SeriousDlqin2yrs", "age"], axis=1).fillna(0)
y_reg = df["age"].fillna(df["age"].median())

# Train-test split
X_train_r, X_test_r, y_train_r, y_test_r = train_test_split(
    X_reg, y_reg, test_size=0.3, random_state=42
)

# Train linear regression
model = LinearRegression()
model.fit(X_train_r, y_train_r)

# Predictions
y_pred = model.predict(X_test_r)

# Metrics
mse = mean_squared_error(y_test_r, y_pred)
rmse = np.sqrt(mse)
mape = mean_absolute_percentage_error(y_test_r, y_pred)
r2 = r2_score(y_test_r, y_pred)

print(f"MSE: {mse:.4f}")
print(f"RMSE: {rmse:.4f}")
print(f"MAPE: {mape:.4f}")
print(f"R²: {r2:.4f}")
