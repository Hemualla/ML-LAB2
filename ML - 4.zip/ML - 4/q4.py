import numpy as np
import matplotlib.pyplot as plt
from sklearn.neighbors import KNeighborsClassifier

# Generate training data from A3
np.random.seed(42)
X_train_demo = np.random.uniform(1, 10, (20, 2))
y_train_demo = np.random.choice([0, 1], size=20)

# Generate test grid
x_values = np.arange(0, 10.1, 0.1)
y_values = np.arange(0, 10.1, 0.1)
xx, yy = np.meshgrid(x_values, y_values)
X_test_demo = np.c_[xx.ravel(), yy.ravel()]

# Train kNN
knn_demo = KNeighborsClassifier(n_neighbors=3)
knn_demo.fit(X_train_demo, y_train_demo)

# Predictions
y_pred_demo = knn_demo.predict(X_test_demo)

# Scatter plot
plt.scatter(X_test_demo[:,0], X_test_demo[:,1], c=y_pred_demo, cmap="bwr", alpha=0.2)
plt.scatter(X_train_demo[:,0], X_train_demo[:,1], c=y_train_demo, cmap="bwr", edgecolors="k")
plt.title("kNN Classification with k=3")
plt.show()
