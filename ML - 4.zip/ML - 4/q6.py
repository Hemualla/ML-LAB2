import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier

# Load dataset
df = pd.read_csv("GiveMeSomeCredit.csv")

# Choose two features
features = ["age", "DebtRatio"]
X_real = df[features].dropna().values
y_real = df["SeriousDlqin2yrs"].dropna().values

# Train-test split
X_real_train, X_real_test, y_real_train, y_real_test = train_test_split(
    X_real, y_real, test_size=0.9, random_state=42
)

# Fit kNN
knn_real = KNeighborsClassifier(n_neighbors=5)
knn_real.fit(X_real_train, y_real_train)

# Create grid for decision boundary
x_min, x_max = X_real[:,0].min(), X_real[:,0].max()
y_min, y_max = X_real[:,1].min(), X_real[:,1].max()
xx, yy = np.meshgrid(np.linspace(x_min, x_max, 200),
                     np.linspace(y_min, y_max, 200))
X_grid = np.c_[xx.ravel(), yy.ravel()]
y_grid_pred = knn_real.predict(X_grid)

# Plot
plt.contourf(xx, yy, y_grid_pred.reshape(xx.shape), cmap="bwr", alpha=0.3)
plt.scatter(X_real_train[:,0], X_real_train[:,1], c=y_real_train, cmap="bwr", edgecolors="k")
plt.title("kNN Decision Boundary (Your Dataset)")
plt.xlabel(features[0])
plt.ylabel(features[1])
plt.show()
