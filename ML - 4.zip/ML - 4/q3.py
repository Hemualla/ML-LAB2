import numpy as np
import matplotlib.pyplot as plt

# Generate random training data
np.random.seed(42)
X_train_demo = np.random.uniform(1, 10, (20, 2))
y_train_demo = np.random.choice([0, 1], size=20)

# Scatter plot
plt.scatter(X_train_demo[:,0], X_train_demo[:,1], c=y_train_demo, cmap="bwr", s=50, edgecolors="k")
plt.xlabel("Feature X")
plt.ylabel("Feature Y")
plt.title("Random Training Data (20 points)")
plt.show()
