import pandas as pd
df = pd.read_csv("GiveMeSomeCredit.csv")
df = df.dropna()
X = df.drop(columns=["SeriousDlqin2yrs"])
y = df["SeriousDlqin2yrs"]
import numpy as np

class_0 = X[y == 0]
class_1 = X[y == 1]

centroid_0 = class_0.mean(axis=0)
centroid_1 = class_1.mean(axis=0)

spread_0 = class_0.std(axis=0)
spread_1 = class_1.std(axis=0)

interclass_distance = np.linalg.norm(centroid_0 - centroid_1)

print("Centroid (Class 0):\n", centroid_0)
print("\nCentroid (Class 1):\n", centroid_1)
print("\nSpread (Class 0):\n", spread_0)
print("\nSpread (Class 1):\n", spread_1)
print("\nInterclass Distance:", interclass_distance)
