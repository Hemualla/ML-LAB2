import pandas as pd
df = pd.read_csv("GiveMeSomeCredit.csv")
target_col = 'SeriousDlqin2yrs'
def calculate_gini(series):
    counts = series.value_counts()
    total = len(series)
    gini = 1 - sum((count / total) ** 2 for count in counts)
    return gini
gini_value = calculate_gini(df[target_col])
print(f"Gini Index of {target_col}: {gini_value:.4f}")