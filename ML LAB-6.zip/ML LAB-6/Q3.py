import pandas as pd
import numpy as np
from math import log2
df = pd.read_csv("GiveMeSomeCredit.csv")
target_col = 'SeriousDlqin2yrs'
def entropy(series):
    counts = series.value_counts()
    total = len(series)
    return -sum((count/total) * log2(count/total) for count in counts)
def information_gain(df, feature, target):
    total_entropy = entropy(df[target])
    values = df[feature].unique()
    weighted_entropy = 0
    for val in values:
        subset = df[df[feature] == val]
        weighted_entropy += (len(subset)/len(df)) * entropy(subset[target])
    return total_entropy - weighted_entropy
for col in df.columns:
    if df[col].dtype != 'object' and col != target_col:
        df[col] = pd.cut(df[col], bins=4, labels=False)
gains = {col: information_gain(df, col, target_col) for col in df.columns if col != target_col}
root_feature = max(gains, key=gains.get)
print("Information Gains:", gains)
print("Root Node Feature:", root_feature)
