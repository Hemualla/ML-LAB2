import pandas as pd
from sklearn.tree import DecisionTreeClassifier, plot_tree
import matplotlib.pyplot as plt
df = pd.read_csv("GiveMeSomeCredit.csv")
target_col = 'SeriousDlqin2yrs'
X = df.drop(columns=[target_col]).select_dtypes(include=['number']).fillna(0)
y = df[target_col]
clf = DecisionTreeClassifier(max_depth=3)
clf.fit(X, y)
plt.figure(figsize=(20,10))
plot_tree(clf, feature_names=X.columns, class_names=['No', 'Yes'], filled=True)
plt.show()