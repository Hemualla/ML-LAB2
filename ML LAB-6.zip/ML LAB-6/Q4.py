import pandas as pd
df = pd.read_csv("GiveMeSomeCredit.csv")
def binning(series, bins=4, method='equal_width'):
    if method == 'equal_width':
        return pd.cut(series, bins=bins, labels=False)
    elif method == 'frequency':
        return pd.qcut(series, q=bins, labels=False)
    else:
        raise ValueError("Method should be 'equal_width' or 'frequency'")
col_to_bin = 'age'
df[col_to_bin] = binning(df[col_to_bin], bins=5, method='frequency')
print(df[[col_to_bin]].head())