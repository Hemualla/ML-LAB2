# Packages
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from xgboost import XGBRegressor
from sklearn.impute import SimpleImputer

# Load dataset
data = pd.read_csv("GiveMeSomeCredit .csv")

# Example: predict "RevolvingUtilizationOfUnsecuredLines"
X = data.drop("RevolvingUtilizationOfUnsecuredLines", axis=1)
y = data["RevolvingUtilizationOfUnsecuredLines"]

# Handle missing values
imputer = SimpleImputer(strategy="median")
X = imputer.fit_transform(X)

# Split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

models = {
    "Linear": LinearRegression(),
    "RandomForest": RandomForestRegressor(),
    "GradientBoosting": GradientBoostingRegressor(),
    "XGB": XGBRegressor()
}

for name, reg in models.items():
    reg.fit(X_train, y_train)
    preds = reg.predict(X_test)
    print(f"{name}: MSE={mean_squared_error(y_test, preds):.4f}, R2={r2_score(y_test, preds):.4f}")
