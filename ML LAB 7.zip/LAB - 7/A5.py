# Packages
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import AgglomerativeClustering, KMeans, MiniBatchKMeans
from sklearn.impute import SimpleImputer
from sklearn.decomposition import PCA

# Load dataset
data = pd.read_csv("GiveMeSomeCredit .csv")
X = data.drop("SeriousDlqin2yrs", axis=1)

# Handle missing values
imputer = SimpleImputer(strategy="median")
X = imputer.fit_transform(X)

# Standardize
X_scaled = StandardScaler().fit_transform(X)

# Reduce dimensions with PCA (keep top 10)
pca = PCA(n_components=10, random_state=42)
X_reduced = pca.fit_transform(X_scaled)

# ---- Use small sample for hierarchical clustering ----
X_sample = X_reduced[:3000]   # Only first 3000 rows

# Hierarchical clustering
hier = AgglomerativeClustering(n_clusters=3)
labels_hier = hier.fit_predict(X_sample)

# KMeans (scalable clustering on reduced dataset)
kmeans = KMeans(n_clusters=3, random_state=42)
labels_kmeans = kmeans.fit_predict(X_reduced)

# MiniBatchKMeans (faster + scalable)
mbkmeans = MiniBatchKMeans(n_clusters=3, batch_size=1000, random_state=42)
labels_mbkmeans = mbkmeans.fit_predict(X_reduced)

print("Hierarchical (sampled) Labels:", labels_hier[:20])
print("KMeans Labels:", labels_kmeans[:20])
print("MiniBatchKMeans Labels:", labels_mbkmeans[:20])
